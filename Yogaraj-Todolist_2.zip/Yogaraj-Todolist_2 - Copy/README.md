# Flux Todo List Example

# Getting Started

the project get it running:
```
npm install
npm start
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.
