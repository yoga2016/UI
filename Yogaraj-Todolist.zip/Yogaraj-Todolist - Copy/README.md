# Flux Todo List Example

This code is for a tutorial [here](http://tylermcginnis.com/reactjs-tutorial-pt-3-architecting-react-js-apps-with-flux/).

# Getting Started

Clone the project and get it running:
```
npm install
npm start
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.
